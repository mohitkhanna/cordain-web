package Parser;

use strict;
use warnings;

sub new
{
    my $self = {};
    bless($self);

    $self->reset_all();
    $self->{REGEXES} = "";
    $self->setup_regexes();

    return($self);
}

sub setup_regexes
{
    my $self = shift;
    $self->{REGEXES} = {
        "dynamic" => [
            "^.* --- process request time: ([0-9]*?) ms --- .* server: ([[:alnum:]\:\.\-]*), request: \"([[:alnum:][:space:]\:\/\.\?\&\-\_]*)\", upstream: \"([[:alnum:][:space:]\:\/\.\?\&\-\_]*)\", host: \"([[:alnum:]\:\/\.\-]*)\"",
            [
                "MILISECONDS",
                "SERVER",
                "REQUEST",
                "UPSTREAM",
                "HOST"
            ]
        ],
        "static" => [
            "^.* --- process request time: ([0-9]*?) ms --- .* server: ([[:alnum:]\:\.\-]*), request: \"([[:alnum:][:space:]\:\/\.\?\&\-\_]*)\", host: \"([[:alnum:]\:\/\.\-]*)\"",
            [
                "MILISECONDS",
                "SERVER",
                "REQUEST",
                "HOST"
            ]
        ]
    };
}

sub reset_all
{
    my $self = shift;

    $self->{REQUEST} = "";
    $self->{UPSTREAM} = "";
    $self->{HOST} = "";
    $self->{SERVER} = "";
    $self->{CATEGORY} = "";
    $self->{MILISECONDS} = "";
    $self->{REGEX} = "";
}

sub parse_line
{
    my $self = shift;
    my $line = shift;
    my $parsed_line = shift;
    if (!$line)
    {
        die "you need to pass me a logline\n";
    }
    chomp($line);
    $self->reset_all();
    $self->{LOG_LINE} = $line;
    if ($self->find_category() == 0)
    {
        return 0;
    }
    $self->extract_values();
    #$self->print_values();

    $parsed_line->{REQUEST} = $self->{REQUEST};
    $parsed_line->{HOST} = $self->{HOST};
    $parsed_line->{SERVER} = $self->{SERVER};
    $parsed_line->{MILISECONDS} = $self->{MILISECONDS};
    if ($self->{CATEGORY} eq "dynamic")
    {
        $parsed_line->{UPSTREAM} = $self->{UPSTREAM};
    }
    return(1);
}

sub print_values
{
    my $self = shift;

    print "printing stored values\n";
    print "category: " . $self->{CATEGORY} . "\n";
    print "miliseconds: " . $self->{MILISECONDS} . "\n";
    print "server: " . $self->{SERVER} . "\n";
    print "request: " . $self->{REQUEST} . "\n";
    print "upstream: " . $self->{UPSTREAM} . "\n";
    print "host: " . $self->{HOST} . "\n";
}

sub extract_values
{
    my $self = shift;
    my @values;
    my $value;
    my $regex = @{$self->{REGEX}}[0];
    my $i=0;
    $_ = $self->{LOG_LINE};
    @values = /@{$self->{REGEX}}[0]/;
    foreach $value(@values)
    {
        $self->{@{@{$self->{REGEX}}[1]}[$i]} = $value;
        $i++;
    }
}

sub find_category
{
    my $self = shift;    
    my $regex;
    my $key;

    keys %{$self->{REGEXES}};
    while (($key, $regex) = each %{$self->{REGEXES}})
    {
        if ($self->{LOG_LINE} =~ /@{$regex}[0]/)
        {
            $self->{CATEGORY} = $key;
            $self->{REGEX} = $regex;
            return 1;
        }
    }
    return 0;
}

1
