#!/usr/bin/perl

use strict;
use warnings;

use Getopt::Std;
use IO::Handle;
use Parser;
use DataStorage;
use Analyzer;
use Data::Dumper;


my %opts;

getopts('ruho', \%opts) or usage();

if (
    ((defined($opts{'u'})) and ((defined($opts{'o'})) or (defined($opts{'r'})))) or 
    ((defined($opts{'r'})) and ((defined($opts{'o'})) or (defined($opts{'u'})))) or 
    ((defined($opts{'o'})) and ((defined($opts{'u'})) or (defined($opts{'r'})))) or 
    ((!defined($opts{'u'})) and (!defined($opts{'o'})) and (!defined($opts{'r'}))) or 
    defined($opts{'h'})
) { print "-h : this help message\n";
    print "-u : group by upstream\n";
    print "-o : group by host\n";
    print "-r : group by request\n";
    exit;
}

my $key;

$key = "UPSTREAM" if (defined($opts{'u'}));
$key = "REQUEST" if (defined($opts{'r'}));
$key = "HOST" if (defined($opts{'o'}));


my $parser = new Parser();
my $storage = new DataStorage($key);
my $analyzer = new Analyzer();
my $data;
my @lines;
my $i = 0;
my $j;
my %parsed_line;

while (<STDIN>)
{
    push(@lines, $_);
}

autoflush STDOUT,1;
foreach (@lines)
{
    print "|";
    for ($j = 0; $j < 100; $j++)
    {
        if ($j < ((100 / $#lines) * $i))
        {
            print "#"
        }
        else
        {
            print "_";
        }
    }
    print "|\r";
        #print "" . ((100 / $#lines) * $i) . "%    \r";
    foreach $key(keys(%parsed_line))
    {
        delete($parsed_line{$key});
    }
    $data = $parser->parse_line($_, \%parsed_line);
    if ($data)
    {
        $storage->add_data(\%parsed_line);
    }
    $i++;
}
for ($j = 0; $j < 102; $j++)
{
    print " ";
}
print "\r";
autoflush STDOUT,0;

$analyzer->process($storage->get_data_ref());

