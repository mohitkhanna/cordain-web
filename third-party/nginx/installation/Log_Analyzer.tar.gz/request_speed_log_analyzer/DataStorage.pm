package DataStorage;

use strict;
use warnings;

sub new
{
    my $self = {};
    shift;
    $self->{KEY} = shift;
    if (!$self->{KEY})
    {
        die "you need to pass me the key to group by\n";
    }
    $self->{STORAGE} = {};
    bless($self);
    return($self);
}

sub add_data
{
    my $self = shift;
    my $data = shift;
    my $miliseconds;

    if (!exists $data->{$self->{KEY}})
    {
        return 0;
    }

    if (exists $self->{STORAGE}->{$data->{$self->{KEY}}})
    {
        push(@{$self->{STORAGE}->{$data->{$self->{KEY}}}},$data->{MILISECONDS});
    }
    else
    {
        @{$self->{STORAGE}->{$data->{$self->{KEY}}}} = ($data->{MILISECONDS});
    }
}

sub get_data_ref
{
    my $self = shift;
    return (\$self->{STORAGE});
}

sub print_data
{
    my $self = shift;
    my $key;
    my $value;
    my $ms;

    while (($key, $value) = each(%{$self->{STORAGE}}))
    {
        print "key: " . $key . "\n";
        foreach $ms(@{$self->{STORAGE}->{$key}})
        {
            print "ms: " . $ms . "\n";
        }
    }
}

1
