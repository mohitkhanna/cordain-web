package Analyzer;

use strict;
use warnings;
use POSIX qw(floor);
use Data::Dumper;


sub new{
    my $self = {};
    $self->{DATA} = {};
    $self->{AVERAGED_DATA} = {};
    bless($self);
    return($self);
}

sub process
{
    my $self = shift;
    my $key;
    my $ms_array;
    my $ms_value;
    my $ms_sum;
    my $ms_valcount;
    my @sorted;
    $self->{DATA} = shift;
    if (!$self->{DATA})
    {
        return 0;
    }
    
    while (($key, $ms_array) = each(%{${$self->{DATA}}}))
    {
        $ms_sum = 0;
        $ms_valcount = 0;
        foreach $ms_value(@{$ms_array})
        {
            $ms_sum += $ms_value;
            $ms_valcount++;
        }
        $self->{AVERAGED_DATA}->{$key} = {
            'avg' => floor($ms_sum / $ms_valcount),
            'valcount' => $ms_valcount
        };
    }

    @sorted = sort { $self->{AVERAGED_DATA}->{$a}->{'avg'} <=> $self->{AVERAGED_DATA}->{$b}->{'avg'} } keys %{$self->{AVERAGED_DATA}};

    print "\n";
    foreach $key (@sorted)
    {
        print "\n" . $key . " --- avg ms: " . $self->{AVERAGED_DATA}->{$key}->{'avg'} . ", value count: " . $self->{AVERAGED_DATA}->{$key}->{'valcount'};
    }
    print " <--- THE WINNER\n\n";
}

1
